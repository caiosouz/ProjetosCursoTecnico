IMPORTEM O BANCO DE DADOS WebContent/database/db_projeto.sql para o mysql de voces...

--> LOGIN:
NOME: host
CPF: 123456
