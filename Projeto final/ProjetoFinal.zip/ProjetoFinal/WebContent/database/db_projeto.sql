-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05-Jun-2020 às 18:10
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_animal`
--

CREATE TABLE `tb_animal` (
  `ID_codigo` int(11) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Sobrenome` varchar(150) NOT NULL,
  `Raca` varchar(20) DEFAULT NULL,
  `Tipo` varchar(20) DEFAULT NULL,
  `Idade` int(11) DEFAULT NULL,
  `Alergico` varchar(5) DEFAULT NULL,
  `Cliente` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_animal`
--

INSERT INTO `tb_animal` (`ID_codigo`, `Nome`, `Sobrenome`, `Raca`, `Tipo`, `Idade`, `Alergico`, `Cliente`) VALUES
(1, 'Lucas Francisco', 'Custódio', 'n sei ', 'lala', 12, 'nao', 'Lucas '),
(2, 'auau', 'n sei', 'pitibu', 'oi', 12, 'teste', 'eu'),
(3, 'eqw', 'Costa', 'pitibu', 'qwe', 12, 'sa', 'eqw'),
(4, 'auau', 'da silva', 'pitibu', 'alegre', 12, 'nao', 'maria das dores'),
(5, 'thor', 'ferreira', 'viralata', 'cachorro', 3, 'não', 'Kauã');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cliente`
--

CREATE TABLE `tb_cliente` (
  `ID_codigo` int(11) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Sobrenome` varchar(150) DEFAULT NULL,
  `Endereco` varchar(255) DEFAULT NULL,
  `Cidade` varchar(45) DEFAULT NULL,
  `Telefone` varchar(20) DEFAULT NULL,
  `Celular` varchar(20) DEFAULT NULL,
  `CPF` varchar(15) NOT NULL,
  `RG` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_consulta`
--

CREATE TABLE `tb_consulta` (
  `ID_codigo` int(11) NOT NULL,
  `Datahora` datetime DEFAULT NULL,
  `Diagnostico` varchar(20) DEFAULT NULL,
  `Valor` float DEFAULT NULL,
  `Peso` float DEFAULT NULL,
  `Altura` float DEFAULT NULL,
  `Veterinario` varchar(20) NOT NULL,
  `Animal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

CREATE TABLE `tb_usuario` (
  `ID_codigo` int(20) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Sobrenome` varchar(150) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Senha` varchar(20) NOT NULL,
  `CRV` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_veterinario`
--

CREATE TABLE `tb_veterinario` (
  `ID_CRV` int(11) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Sobrenome` varchar(150) NOT NULL,
  `Cidade` varchar(45) DEFAULT NULL,
  `Endereco` varchar(255) DEFAULT NULL,
  `Celular` varchar(20) DEFAULT NULL,
  `CPF` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_veterinario`
--

INSERT INTO `tb_veterinario` (`ID_CRV`, `Nome`, `Sobrenome`, `Cidade`, `Endereco`, `Celular`, `CPF`) VALUES
(1, 'Luciano', '', NULL, NULL, NULL, '123456789'),
(2, 'host', 'aaa', 'aaa', 'aaa', 'aaa', 'host'),
(3, 'host', 'aaa', 'aaa', 'aaa', 'aaa', '123456');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_animal`
--
ALTER TABLE `tb_animal`
  ADD PRIMARY KEY (`ID_codigo`);

--
-- Índices para tabela `tb_cliente`
--
ALTER TABLE `tb_cliente`
  ADD PRIMARY KEY (`ID_codigo`),
  ADD UNIQUE KEY `CPF` (`CPF`),
  ADD UNIQUE KEY `RG` (`RG`);

--
-- Índices para tabela `tb_consulta`
--
ALTER TABLE `tb_consulta`
  ADD PRIMARY KEY (`ID_codigo`);

--
-- Índices para tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD PRIMARY KEY (`ID_codigo`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `CRV` (`CRV`);

--
-- Índices para tabela `tb_veterinario`
--
ALTER TABLE `tb_veterinario`
  ADD PRIMARY KEY (`ID_CRV`),
  ADD UNIQUE KEY `CPF` (`CPF`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_animal`
--
ALTER TABLE `tb_animal`
  MODIFY `ID_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tb_cliente`
--
ALTER TABLE `tb_cliente`
  MODIFY `ID_codigo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_consulta`
--
ALTER TABLE `tb_consulta`
  MODIFY `ID_codigo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  MODIFY `ID_codigo` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_veterinario`
--
ALTER TABLE `tb_veterinario`
  MODIFY `ID_CRV` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
