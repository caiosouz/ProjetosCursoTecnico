package com.br.project.model;

public class Animal {
	private int id_codigo;
	private String nome;
	private String sobrenome;
	private String raca;
	private String tipo;
	private int idade;
	private String alergico;
	private String cliente;
	
	public int getId_codigo() {
		return this.id_codigo;
	}
	public void setId_codigo(int id) {
		this.id_codigo = id;
	}
	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSobrenome() {
		return this.sobrenome;
	}
	public void setSobrenome(String sob) {
		this.sobrenome = sob;
	}
	
	public String getRaca() {
		return this.raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	
	public String getTipo() {
		return this.tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public int getIdade() {
		return this.idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	public String getAlergico() {
		return this.alergico;
	}
	public void setAlergico(String alergico) {
		this.alergico = alergico;
	}
	
	public String getCliente() {
		return this.cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
}
