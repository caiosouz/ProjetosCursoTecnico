package com.br.project.model;

public class Cliente {
	private int id_codigo;
	private String nome;
	private String sobrenome;
	private String endereco;
	private String cidade;
	private String telefone;
	private String celular;
	private String cpf;
	
	public int getId_codigo() {
		return this.id_codigo;
	}
	public void setId_codigo(int id) {
		this.id_codigo = id;
	}
	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSobrenome() {
		return this.sobrenome;
	}
	public void setSobrenome(String sobre) {
		this.sobrenome = sobre;
	}
	
	public String getEndereco() {
		return this.endereco;
	}
	public void setEndereco(String end) {
		this.endereco = end;
	}
	
	public String getCidade() {
		return this.cidade;
	}
	public void setCidade(String cid) {
		this.cidade = cid;
	}
	
	public String getTelefone() {
		return this.telefone;
	}
	public void setTelefone(String tel) {
		this.telefone = tel;
	}
	
	public String getCelular() {
		return this.celular;
	}
	public void setCelular(String cel) {
		this.celular = cel;
	}
	
	public String getCpf() {
		return this.cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
}
