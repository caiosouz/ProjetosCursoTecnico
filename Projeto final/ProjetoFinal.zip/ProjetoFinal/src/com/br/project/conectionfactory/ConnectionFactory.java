package com.br.project.conectionfactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	
	public Connection getConnection() {
		
		Connection con = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
			System.out.println("Erro no ForClass");
		}
		
		try {
			
			con = DriverManager.getConnection("jdbc:mysql://localhost/db_projeto","root","");
			return con;
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			System.out.println("Erro no DriverManager");
		}
		
		return null;
	}
}
