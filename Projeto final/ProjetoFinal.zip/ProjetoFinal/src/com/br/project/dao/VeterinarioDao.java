package com.br.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.br.project.conectionfactory.ConnectionFactory;
import com.br.project.model.Veterinario;

public class VeterinarioDao {
	
	Connection con;
	public VeterinarioDao() {
		con = new ConnectionFactory().getConnection();
	}
	
	public void insere(Veterinario veterinario) {
		
		String sql = "INSERT INTO ---tabelaVeterinario--- (Nome,Sobrenome,Cidade,Endereco,Celular,CPF) VALUES(?,?,?,?,?,?)";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, veterinario.getNome());  
            stmt.setString(2, veterinario.getSobrenome());  
            stmt.setString(3, veterinario.getCidade());  
            stmt.setString(4, veterinario.getEndereco());  
            stmt.setString(5, veterinario.getCelular());
            stmt.setString(6, veterinario.getCpf());

            stmt.execute();  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao inserir no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - veterinario.insere");
			}
        }
	}
	
	public void exclui(Veterinario veterinario) {
		
		String sql = "DELETE FROM ---TabelaVeterinario--- WHERE Nome = ?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, veterinario.getNome()); 

            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao excluir no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - veterinario.exclui");
			}
        }
	}

	public void atualiza(Veterinario veterinario) {
		
		String sql = "UPDATE ---TabelaVeterinario--- SET Nome=?, Sobrenome=?, Endereco=?, Cidade=?, Celular=?, CPF=? WHERE Nome=?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, veterinario.getNome()); 
            stmt.setString(2, veterinario.getSobrenome()); 
            stmt.setString(3, veterinario.getEndereco());  
            stmt.setString(4, veterinario.getCidade());  
            stmt.setString(5, veterinario.getCelular());
            stmt.setString(6, veterinario.getCpf());
            stmt.setString(7, veterinario.getNome()); 
            
            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao atualizar no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - veterinario.atualiza");
			}
        }
	}
	
	public boolean seleciona(Veterinario veterinario) {
		
		String sql = "SELECT * FROM tb_veterinario WHERE Nome = ? AND CPF = ?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, veterinario.getNome()); 
            stmt.setString(2, veterinario.getCpf());

            ResultSet rs = stmt.executeQuery();
            
            if(rs.next()) {
            	return true;
            }
            
            stmt.close();
            con.close();
        } catch (SQLException u) {  
        	
        	System.out.println("Erro ao selecionar no banco"+ u);
        } finally {
        	
        }
        
        return false;
	}
}