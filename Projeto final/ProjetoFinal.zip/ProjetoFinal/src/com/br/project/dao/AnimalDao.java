package com.br.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.br.project.conectionfactory.ConnectionFactory;
import com.br.project.model.Animal;

public class AnimalDao {
	
	Connection con;
	
	public AnimalDao() {
		con = new ConnectionFactory().getConnection();
	}
	
	public void insere(Animal animal) {
		
		String sql = "INSERT INTO tb_animal (Nome,Sobrenome,Raca,Tipo,Idade,Alergico,Cliente) VALUES(?,?,?,?,?,?,?)";  
		PreparedStatement stmt = null;
		
        try {  
            
        	stmt = con.prepareStatement(sql);  
        	
        	stmt.setString(1, animal.getNome()); 
        	stmt.setString(2, animal.getSobrenome()); 
            stmt.setString(3, animal.getRaca());  
            stmt.setString(4, animal.getTipo());  
            stmt.setInt(5, animal.getIdade());
            stmt.setString(6, animal.getAlergico());
            stmt.setString(7, animal.getCliente()); 
        	
            stmt.execute();  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao inserir no banco"+ u);
        }catch (NullPointerException u) {  
            
        	System.out.println("Erro ao inserir no banco"+ u);
        }
	}
	
	public void exclui(Animal animal) {
		
		String sql = "DELETE FROM ---TabelaAnimal--- WHERE Nome = ?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, animal.getNome()); 

            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao excluir no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - animal.exclui");
			}
        }
	}

	public void atualiza(Animal animal) {
		
		String sql = "UPDATE ---TabelaAnimal--- SET Nome=?,Raca=?,Tipo=?,Idade=?,Alergico=?,Cliente=? WHERE Nome=?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, animal.getNome()); 
            stmt.setString(2, animal.getRaca());  
            stmt.setString(3, animal.getTipo());  
            stmt.setInt(4, animal.getIdade());
            stmt.setString(5, animal.getAlergico());
            stmt.setString(6, animal.getCliente()); 
            
            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao atualizar no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - animal.atualiza");
			}
        }
	}
	
	public ArrayList<Animal> seleciona(Animal animal) {
		
		ArrayList<Animal> lista = new ArrayList<>(); 
		String sql = "SELECT * FROM tb_animal WHERE Nome = ? AND Idade=?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, animal.getNome()); 
            stmt.setInt(2, animal.getIdade()); 

            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
            	Animal a = new Animal();
            	a.setNome(rs.getString("Nome"));
            	a.setSobrenome(rs.getString("Sobrenome"));
            	a.setRaca(rs.getString("Raca"));
            	a.setTipo(rs.getString("Tipo"));
            	a.setIdade(rs.getInt("Idade"));
            	a.setAlergico(rs.getString("Alergico"));
            	a.setCliente(rs.getString("Cliente"));
            	lista.add(a);
            }
            
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao selecionar no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - animal.seneciona");
			}
        }
        
        return lista;
	}
}