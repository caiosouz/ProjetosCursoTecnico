package com.br.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.br.project.conectionfactory.ConnectionFactory;
import com.br.project.model.Cliente;

public class ClienteDao {
	
	Connection con;
	public ClienteDao() {
		con = new ConnectionFactory().getConnection();
	}
	
	public void insere(Cliente cliente) {
		
		String sql = "INSERT INTO ---tabelaCliente--- (Nome, Sobrenome,Endereco,Cidade,Telefone,Celular,CPF) VALUES(?,?,?,?,?,?,?)";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getSobrenome());
            stmt.setString(3, cliente.getEndereco());  
            stmt.setString(4, cliente.getCidade());  
            stmt.setString(5, cliente.getTelefone());
            stmt.setString(6, cliente.getCelular());
            stmt.setString(7, cliente.getCpf());

            stmt.execute();  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao inserir no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - Cliente.insere");
			}
        }
	}
	
	public void exclui(Cliente cliente) {
		
		String sql = "DELETE FROM ---TabelaCliente--- WHERE Nome = ?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, cliente.getNome()); 

            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao excluir no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - Cliente.exclui");
			}
        }
	}

	public void atualiza(Cliente cliente) {
		
		String sql = "UPDATE ---TabelaCliente--- SET Nome=?, Sobrenome=?, Endereco=?, Cidade=?, Telefone=?, Celular=?, CPF=? WHERE Nome=?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, cliente.getNome()); 
            stmt.setString(2, cliente.getSobrenome()); 
            stmt.setString(3, cliente.getEndereco());  
            stmt.setString(4, cliente.getCidade());  
            stmt.setString(5, cliente.getTelefone());
            stmt.setString(6, cliente.getCelular());
            stmt.setString(7, cliente.getCpf());
            stmt.setString(8, cliente.getNome()); 
            
            stmt.execute(sql);  
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao atualizar no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - Cliente.atualiza");
			}
        }
	}
	
	public int seleciona(Cliente cliente) {
		
		String sql = "SELECT * FROM ---TabelaCliente--- WHERE Nome = ? AND Sobrenome=? AND Endereco=? AND Cidade=? AND Telefone=? AND Celular=? AND CPF=?";  

        try {  
            
        	PreparedStatement stmt = con.prepareStatement(sql);  

            stmt.setString(1, cliente.getNome()); 
            stmt.setString(2, cliente.getSobrenome()); 
            stmt.setString(3, cliente.getEndereco()); 
            stmt.setString(4, cliente.getCidade()); 
            stmt.setString(5, cliente.getTelefone()); 
            stmt.setString(6, cliente.getCelular()); 
            stmt.setString(7, cliente.getCpf());  

            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
            	return rs.getInt("ID_Codigo");
            }
            
            stmt.close();
            con.close();
        } catch (SQLException u) {  
            
        	System.out.println("Erro ao selecionar no banco");
        } finally {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Erro ao fechar a conexao - Cliente.seneciona");
			}
        }
        
        return 0;
	}
}
