package com.br.poject.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.br.project.dao.AnimalDao;
import com.br.project.model.Animal;

@WebServlet("/Cadastro")
public class CadastroServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		
		String nome = req.getParameter("nome");
		String sobrenome = req.getParameter("sobrenome");
		String raca = req.getParameter("raca");
		String tipo = req.getParameter("tipo");
		int idade = Integer.parseInt(req.getParameter("idade"));
		String alergico = req.getParameter("alergico");
		String nome_cliente = req.getParameter("nome_cliente");
		
		Animal animal = new Animal();
		animal.setNome(nome);
		animal.setSobrenome(sobrenome);
		animal.setRaca(raca);
		animal.setTipo(tipo);
		animal.setIdade(idade);
		animal.setAlergico(alergico);
		animal.setCliente(nome_cliente);
		
		System.out.println(animal.getNome());
		System.out.println(animal.getSobrenome());
		System.out.println(animal.getRaca());
		System.out.println(animal.getTipo());
		System.out.println(animal.getIdade());
		System.out.println(animal.getAlergico());
		System.out.println(animal.getCliente());
		
		new AnimalDao().insere(animal);
		RequestDispatcher rd = req.getRequestDispatcher("/cadastro.jsp");
		try {
			rd.forward(req, res);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
