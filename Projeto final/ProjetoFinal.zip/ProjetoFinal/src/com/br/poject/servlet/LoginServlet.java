package com.br.poject.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.br.project.dao.VeterinarioDao;
import com.br.project.model.Veterinario;

@WebServlet("/Login")
public class LoginServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		
		String nome = req.getParameter("email");
		String cpf = req.getParameter("senha");
		
		Veterinario vet = new Veterinario();
		vet.setNome(nome);
		vet.setCpf(cpf);
		
		boolean log = new VeterinarioDao().seleciona(vet);
		
		if(log == true) {
			RequestDispatcher rd = req.getRequestDispatcher("index.html");
			try {
				rd.forward(req, res);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.out.println("n logado");
		}
	}
}
