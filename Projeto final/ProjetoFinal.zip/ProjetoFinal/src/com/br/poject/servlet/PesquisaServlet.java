package com.br.poject.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.br.project.dao.AnimalDao;
import com.br.project.dao.VeterinarioDao;
import com.br.project.model.Animal;
import com.br.project.model.Veterinario;

@WebServlet("/Procura")
public class PesquisaServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		
		String nome = req.getParameter("nome");
		int idade = Integer.parseInt(req.getParameter("idade"));
		
		Animal animal = new Animal();
		animal.setNome(nome);
		animal.setIdade(idade);
		System.out.println(animal.getNome());
		System.out.println(animal.getIdade());
		AnimalDao dao = new AnimalDao();
		ArrayList<Animal> lista = dao.seleciona(animal);
		
		// Imprime os dados:
		
		PrintWriter out = null;
		try {
			out = res.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html lang=\"pt-br\">\r\n" + 
				"<head>\r\n" + 
				
				"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
				"    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css\" integrity=\"sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk\" crossorigin=\"anonymous\">\r\n" + 
				"    <title>Consulta</title>\r\n" + 
				"</head>\r\n" + 
				"<body>");
		
		out.println("<ul class=\"nav nav-tabs\">\r\n" + 
				"    <li class=\"nav-item\">\r\n" + 
				"        <a class=\"nav-link active\" href=\"index.html\"><img src=\"images/logofinal.png\" alt=\"Logo\" style=\"height: 50px;\"></a>\r\n" + 
				"    </li>\r\n" + 
				"    <li class=\"nav-item mt-3\" style=\"font-size: 20px;\">\r\n" + 
				"        <a class=\"nav-link\" href=\"cadastro.jsp\">Cadastrar Animal</a>\r\n" + 
				"    </li>\r\n" + 
				"    <li class=\"nav-item mt-3\" style=\"font-size: 20px;\">\r\n" + 
				"        <a class=\"nav-link\" href=\"pesquisa.html\">Pesquisar Animal</a>\r\n" + 
				"    </li>\r\n" + 
				"</ul>\r\n" + 
				"\r\n" + 
				"    <div style=\"text-align: center; margin-top: 50px;font-size:50px;' font-family: 'Times New Roman';\">Animais Encontrados</div>");
		
		out.println("<div style='margin-top:50px'><div>");
		
		for(Animal animais : lista) {
			out.println("<div style='text-align: center;font-size:30px' font-family: 'Times New Roman'>"+"Nome do Animal: "+animais.getNome()+"</div>");
			out.println("<div style='text-align: center;'>"+"Sobrenome do Animal: "+animais.getSobrenome()+"</div>");
			out.println("<div style='text-align: center;'>"+"Ra�a do Animal: "+animais.getRaca()+"</div>");
			out.println("<div style='text-align: center;'>"+"Tipo do Animal: "+animais.getTipo()+"</div>");
			out.println("<div style='text-align: center;'>"+"Idade do Animal: "+animais.getIdade()+"</div>");
			out.println("<div style='text-align: center;'>"+"Alergias: "+animais.getAlergico()+"</div>");
			out.println("<div style=\"text-align: center;\">"+"Nome do Dono do Animal: "+animais.getCliente()+"</div>");
			out.println("<div style=\"margin-bottom: 30px;\"></div>");
		}
		
		out.println("<script src=\"https://code.jquery.com/jquery-3.5.1.slim.min.js\" integrity=\"sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj\" crossorigin=\"anonymous\"></script>\r\n" + 
				"    <script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js\" integrity=\"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo\" crossorigin=\"anonymous\"></script>\r\n" + 
				"    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js\" integrity=\"sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI\" crossorigin=\"anonymous\"></script>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}
}
